/*package org.buddingtechi.apps.service;

import static org.junit.Assert.*;

import java.util.Collection;

import org.aspectj.lang.annotation.Before;
import org.buddingtechi.apps.AbstractTest;
import org.buddingtechi.apps.ws.model.Greeting;
import org.buddingtechi.apps.ws.service.GreetingService;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
@Transactional
public class GreetingServiceTest extends AbstractTest {

	@Autowired
	private GreetingService greetingService;

	@org.junit.Before
	public void setUp(){
		greetingService.evictCache();
	}


	@Test
	public void testName() throws Exception {
		Collection<Greeting> list = greetingService.findAll();
	}
}
*/